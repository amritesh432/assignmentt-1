def largest_element(arr):
    return max(arr)