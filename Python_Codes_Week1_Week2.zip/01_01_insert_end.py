def insert_at_end(arr, x):
    arr.append(x)
    return arr