void insertAtEnd(int arr[], int *n, int x) {
    arr[*n] = x;
    (*n)++;
}